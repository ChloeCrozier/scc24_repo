| Model               | Scenario   | Accuracy              |   Throughput | Latency (in ms)   |
|---------------------|------------|-----------------------|--------------|-------------------|
| stable-diffusion-xl | offline    | (16.44613, 237.99091) |        0.414 | -                 |